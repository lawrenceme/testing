$(document).ready(function() {
    $(function() {
        $('.inactiveUntilOnLoad').removeClass('inactiveUntilOnLoad');
    });
    $('#myCarousel').carousel({
        interval: 3000
    });
    var clickEvent = false;
    $('#myCarousel').on('click', '.nav a', function() {
        clickEvent = true;
        $('.nav li').removeClass('active');
        $(this).parent().addClass('active');
    }).on('slid.bs.carousel', function(e) {
        if (!clickEvent) {
            var count = $('.nav').children().length - 1;
            var current = $('.nav li.active');
            current.removeClass('active').next().addClass('active');
            var id = parseInt(current.data('slide-to'));
            if (count == id) {
                $('.nav li').first().addClass('active');
            }
        }
        clickEvent = false;
    });
    $(".navbar-toggle").on("click", function() {
        $(this).toggleClass("active");
    });
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o), m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-22827403-3', 'auto');
    ga('send', 'pageview');
    $('.fadeleft').addClass("hide_me").viewportChecker({
        classToAdd: 'visible animated fadeInLeft',
        offset: 100
    });
    $('.fadein').addClass("hide_me").viewportChecker({
        classToAdd: 'visible animated fadeIn',
        offset: 100
    });
    $(window).scroll(function() {
        if ($(this).scrollTop() > 70) {
            $('.scrollToTop').stop(true, true).fadeIn();
        } else {
            $('.scrollToTop').stop(true, true).fadeOut();
        }
    });
    $('.scrollToTop').click(function() {
        $('html, body').animate({
            scrollTop: 0
        }, 800);
        return false;
    });
});