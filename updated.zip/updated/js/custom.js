( function( $ ) {
    // Init Skrollr
	if ($(window).width() > 767) {
		var s = skrollr.init({
			render: function(data) {
				//Debugging - Log the current scroll position.
				console.log(data.curTop);
			}
		});
	}
	$(window).on('resize', function () {
		if ($(window).width() <= 767) {
		  skrollr.init().destroy(); // skrollr.init() returns the singleton created above
		}
	)}
} )( jQuery );